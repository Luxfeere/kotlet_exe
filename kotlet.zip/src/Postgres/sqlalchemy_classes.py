from sqlalchemy import Column, Text, Integer, Float, ARRAY, PickleType
from sqlalchemy.ext.declarative import declarative_base


class Logowanie(declarative_base()):
    __tablename__ = "logowanie"

    ID = Column(Integer, primary_key=True)
    login = Column(Text)
    haslo = Column(PickleType)
    status = Column(Text)


class Rozgrywka(declarative_base()):
    __tablename__ = "rozgrywka"

    gra_partia = Column(Integer, primary_key=True)
    gra_nrruch = Column(Integer)
    dealer_karty = Column(ARRAY(Text))
    ruch_gracza = Column(Text)  # Bolek
    akcja_gracza = Column(Text)  # Raise
    gracz1_id = Column(Text)
    gracz1_typ = Column(Integer)
    gracz1_karta1 = Column(Text)
    gracz1_karta2 = Column(Text)
    gracz1_kasa = Column(Integer)
    gracz1_zaklad = Column(Integer)
    gracz1_szansa = Column(Float)
    gracz2_id = Column(Text)
    gracz2_typ = Column(Integer)
    gracz2_karta1 = Column(Text)
    gracz2_karta2 = Column(Text)
    gracz2_kasa = Column(Integer)
    gracz2_zaklad = Column(Integer)
    gracz2_szansa = Column(Float)
    gracz3_id = Column(Text)
    gracz3_typ = Column(Integer)
    gracz3_karta1 = Column(Text)
    gracz3_karta2 = Column(Text)
    gracz3_kasa = Column(Integer)
    gracz3_zaklad = Column(Integer)
    gracz3_szansa = Column(Float)
    gracz4_id = Column(Text)
    gracz4_typ = Column(Integer)
    gracz4_karta1 = Column(Text)
    gracz4_karta2 = Column(Text)
    gracz4_kasa = Column(Integer)
    gracz4_zaklad = Column(Integer)
    gracz4_szansa = Column(Float)
