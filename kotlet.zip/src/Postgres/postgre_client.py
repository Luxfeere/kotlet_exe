from sqlalchemy import create_engine, select, update
from sqlalchemy.orm import sessionmaker
from src.Postgres.sqlalchemy_classes import Logowanie, Rozgrywka
from sqlalchemy.exc import OperationalError
from typing import List
import logging as logger
import hashlib
import os


class PostgreClient:
    def __init__(self, host: str = "localhost", port: str = 5432, database: str = "poker",
                 user: str = "postgres",
                 password: str = "postgres"):
        try:
            self.url = f'postgresql://{user}:{password}@{host}:{port}/{database}'
            self.engine = create_engine(self.url)
            session_create = sessionmaker(self.engine)
            self.session = session_create()
            self.engine.connect()
        except OperationalError as e:
            print("Can't connect to database description:", e)
        except Exception as e:
            logger.error([e, e.__traceback__])


class LogowanieCRUD(PostgreClient):
    def __init__(self, host: str = "localhost", port: str = 5432, database: str = "poker",
                 user: str = "postgres",
                 password: str = "postgres"):
        super().__init__(host=host, port=port, database=database, user=user, password=password)

    def insert(self, login: str, haslo: str, status: str) -> bool:
        try:
            salt = os.urandom(32)
            haslo = salt + hashlib.pbkdf2_hmac('sha256', haslo.encode('utf-8'),salt, 100000)
            self.session.add(Logowanie(login=login, haslo=haslo, status=status))
            self.session.commit()
            return True
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return False
        except Exception as e:
            logger.error([e, e.__traceback__])

    def patch(self, login: str, status: str):
        try:
            stmt = update(Logowanie.__table__).where(Logowanie.login == login).values(**{"status": status})
            self.session.execute(stmt)
            self.session.commit()
            return True
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return False
        except Exception as e:
            logger.error([e, e.__traceback__])

    def query_l_h(self, login: str, haslo: str):
        query = select(Logowanie.__table__).where(login == Logowanie.login)
        try:
            result = [res for res in self.session.execute(query)][0]
            salt = result[2][:32]
            key = result[2][32:]
            new_key = hashlib.pbkdf2_hmac('sha256', haslo.encode('utf-8'), salt, 100000)
            result = [["0", login, haslo]]
            if new_key == key:
                return result
            else:
                result[0][2] = result[0][2]+"wrong_pass"
                return result
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return []
        except Exception as e:
            logger.error([e, e.__traceback__])

    def query_active_players(self):
        query = select(Logowanie.__table__).where(Logowanie.status == "zalogowany")
        try:
            return self.session.execute(query)
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return []
        except Exception as e:
            logger.error([e, e.__traceback__])


class RozgrywkaCRUD(PostgreClient):
    def __init__(self, host: str = "localhost", port: str = 5432, database: str = "poker",
                 user: str = "postgres",
                 password: str = "postgres"):
        super().__init__(host=host, port=port, database=database, user=user, password=password)

    def insert(self, gra_nrruch: int, ruch_gracza: str, akcja_gracza: str, dealer_karty: List[str], gracz1_id: str,
               gracz1_typ: int, gracz1_karta1: str, gracz1_karta2: str, gracz1_kasa: int, gracz1_zaklad: int,
               gracz1_szansa: float, gracz2_id: str, gracz2_typ: int, gracz2_karta1: str, gracz2_karta2: str,
               gracz2_kasa: int, gracz2_zaklad: int, gracz2_szansa: float, gracz3_id: str, gracz3_typ: int,
               gracz3_karta1: str, gracz3_karta2: str, gracz3_kasa: int, gracz3_zaklad: int, gracz3_szansa: float,
               gracz4_id: str, gracz4_typ: int, gracz4_karta1: str, gracz4_karta2: str, gracz4_kasa: int,
               gracz4_zaklad: int, gracz4_szansa: float) -> bool:
        try:
            if akcja_gracza == "INIT":
                gra_partia = self.query() + 1
            else:
                gra_partia = self.query()
                gra_nrruch = self.query_ruch(gra_partia) + 1
            args = locals()
            args.pop('self', None)
            self.session.add(Rozgrywka(**args))
            self.session.commit()
            return True
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return False
        except Exception as e:
            logger.error([e, e.__traceback__])

    def query(self):
        query = select(Rozgrywka.__table__).order_by(Rozgrywka.gra_partia.desc())
        tmp = self.session.execute(query)
        result = [obj for obj in tmp]
        try:
            return result[0].gra_partia
        except IndexError:
            return 0
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return []
        except Exception as e:
            logger.error([e, e.__traceback__])

    def query_ruch(self, nr_partii):
        query = select(Rozgrywka.__table__).where(Rozgrywka.gra_partia == nr_partii).order_by(Rozgrywka.gra_nrruch.desc())
        tmp = self.session.execute(query)
        result = [obj for obj in tmp]
        try:
            return result[0].gra_nrruch
        except IndexError:
            return 0
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return []
        except Exception as e:
            logger.error([e, e.__traceback__])

    def update(self, cards):
        try:
            ruch = [row for row in self.query_latest_data(self.query())][0].gra_nrruch
            stmt = update(Rozgrywka.__table__).where(Rozgrywka.gra_nrruch == ruch).where(Rozgrywka.gra_partia == self.query()).values(**{"dealer_karty": cards})
            self.session.execute(stmt)
            self.session.commit()
            return True
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return False
        except Exception as e:
            logger.error([e, e.__traceback__])

    def query_latest_data(self, nr_partii):
        query = select(Rozgrywka.__table__).where(Rozgrywka.gra_partia == nr_partii).order_by(Rozgrywka.gra_nrruch.desc()).limit(1)
        tmp = self.session.execute(query)
        result = [obj for obj in tmp]
        try:
            return result
        except IndexError:
            return 0
        except OperationalError as e:
            print("Connection with database broken description:", e)
            return []
        except Exception as e:
            logger.error([e, e.__traceback__])


if __name__ == "__main__":
    test = RozgrywkaCRUD(password="postgres")
    Rozgrywka.__table__.create(test.engine, checkfirst=True)
    test2 = LogowanieCRUD(password="postgres")
    Logowanie.__table__.create(test.engine, checkfirst=True)
    #test2.insert("bolekk","bolekk","niezalogowany")
    print(test2.query_l_h("bolekk", "bolekk"))

'''
                            self.rozgrywka_DB.insert(self.runda, self.aktywny_gracz.nazwa, f"Raise {bet}",
                                                     ["TO DO "], self.lista_graczy[0].nazwa, 0,
                                                     str(self.lista_graczy[0].karty[0].__repr__), str(self.lista_graczy[0].karty[1].__repr__),
                                                     self.lista_graczy[0].zetony, self.lista_graczy[0].stawka, 0,
                                                     self.lista_graczy[1].nazwa, 0, str(self.lista_graczy[1].karty[0].__repr__),
                                                     str(self.lista_graczy[1].karty[1].__repr__), self.lista_graczy[1].zetony,
                                                     self.lista_graczy[0].stawka, 0,
                                                     self.lista_graczy[2].nazwa, 0, str(self.lista_graczy[2].karty[0].__repr__),
                                                     str(self.lista_graczy[2].karty[1].__repr__), self.lista_graczy[2].zetony,
                                                     self.lista_graczy[0].stawka, 0,
                                                     self.lista_graczy[3].nazwa, 0, str(self.lista_graczy[3].karty[0].__repr__),
                                                     str(self.lista_graczy[3].karty[1].__repr__), self.lista_graczy[3].zetony,
                                                     self.lista_graczy[0].stawka, 0)
                                                     ZAPAS NA ZAPAS
'''
