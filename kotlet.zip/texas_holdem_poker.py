import os
import random
import itertools
import sys
from collections import Counter
from tkinter import *
import easygui
from PIL import ImageTk, Image
import threading
import queue
import time
import tkinter as tk
from functools import partial
from src.Postgres.postgre_client import LogowanieCRUD, RozgrywkaCRUD

all_in = False
only_once = True
once = True
dek = ['']
odloguj = True
ilosc_graczy = 4
synchro_bit = False
HASLO_DO_BAZY_DANYCH = 'postgres'
z_bazy = False
log_list = ["", "", "", "", ""]
correct_steps = [False, False]  # = [False, False]
host = False
wygrana = False
player_names = ['Gracz1', 'Gracz2', 'Gracz3', 'Gracz4']
actual_player = ''
nickname = ''
tekst = ""
flop = False
twice = 1
data_retrieved = False


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


db_logowanie = LogowanieCRUD(password=HASLO_DO_BAZY_DANYCH)#, host='192.168.30.11')
db_rozgrywka = RozgrywkaCRUD(password=HASLO_DO_BAZY_DANYCH)#, host='192.168.30.11')

question_player = None
button0 = None
button1 = None
button2 = None
button3 = None
button4 = None
akcja = None


def update_log(text: str):
    log_list.insert(0, text)
    log_list.pop(-1)


def main():
    class EkranLogowaniaGUI:

        def __init__(self):
            self.root = Tk()
            self.root.resizable(0, 0)
            # self.root.state('zoomed')
            self.root.geometry("500x500")
            self.root.title("Texas Hold'em - ekran logowania")
            self.image = tk.PhotoImage(file=resource_path("Karty/menu.png"))
            label = tk.Label(image=self.image)
            label.place(x=0, y=0, relwidth=1.0, relheight=1.0, anchor="nw")

            usernameLabel = Label(self.root, text="Login").place(x=150, y=200)
            username = StringVar()
            usernameEntry = Entry(self.root, textvariable=username).place(x=200, y=200)

            # password label and password entry box
            passwordLabel = Label(self.root, text="Hasło").place(x=150, y=220)
            password = StringVar()
            passwordEntry = Entry(self.root, textvariable=password, show='*').place(x=200, y=220)

            validateLogin = partial(EkranLogowaniaGUI.validateLogin, username, password, self)
            # login button
            loginButton = Button(self.root, text="Zaloguj", font=("Calibri", 12), bd=3, command=validateLogin).place(x=140, y=275, relheight = 0.08, relwidth = 0.45)
            #relx = 0.20, rely = 0.32, relheight = 0.10, relwidth = 0.65, anchor = "sw"

        def validateLogin(username, password, self):
            global nickname, HASLO_DO_BAZY_DANYCH, db_logowanie
            name = username.get()
            passw = password.get()
            try:
                matching_logins = [match for match in db_logowanie.query_l_h(name, passw)]
            except:
                matching_logins = False
                login = passw + "Nope"
                p = name + "Nope"

            if matching_logins:
                login = matching_logins[0][1]
                p = matching_logins[0][2]
            else:
                login = ""
                p = ""
            player_names[0] = login

            if login == username.get() and p == password.get():
                nickname = login
                EkranLogowaniaGUI.Player1 = 1
                easygui.msgbox("Logowanie poprawne, zalogowano.")
                correct_steps[0] = True
                db_logowanie.patch(login, "zalogowany")
                self.root.destroy()
            else:
                EkranLogowaniaGUI.Player1 = 0
                easygui.msgbox("Błedne logowanie. Sprawdź swój login i hasło.")
            return

        def run(self):
            self.root.mainloop()

        def close(self):
            easygui.msgbox("Close")
            self.root.destroy()

        def action(self):
            login = "l"
            p = "h"
            easygui.msgbox(login)
            easygui.msgbox(p)
            if login == EkranLogowaniaGUI.username and p == EkranLogowaniaGUI.password:
                EkranLogowaniaGUI.Player1 = 1
            else:
                EkranLogowaniaGUI.Player1 = 0
                easygui.msgbox("błedne logowanie")
                a = EkranLogowaniaGUI()
                a.run()
            easygui.msgbox("Player1:")
            easygui.msgbox(EkranLogowaniaGUI.Player1)
            self.close()

    class EkranWyboruGUI:

        def __init__(self):
            self.root = Tk()
            self.root.resizable(0, 0)
            self.root.geometry("450x350")
            self.root.title("Texas Hold'em - ekran wyboru gry")
            self.image = tk.PhotoImage(file=resource_path("Karty/menu2.png"))
            label = tk.Label(image=self.image)
            label.place(x=0, y=0, relwidth=1.0, relheight=1.0, anchor="nw")
            self.btn = Button(self.root, text="Host")
            self.btn2 = Button(self.root, text="Gość")
            self.btn3 = Button(self.root, text="Wyjdź z gry")
            self.btn.pack(padx=50, pady=50)
            self.btn.config(command=self.action_single_player, height=2, width=70)
            self.btn2.pack(padx=50, pady=51)
            self.btn2.config(command=self.action_multi_player, height=2, width=70)
            self.btn3.pack(padx=50, pady=51)
            self.btn3.config(command=self.action_koniec, height=2, width=70)

        def run(self):
            self.root.mainloop()

        def action_single_player(self):
            global host, ilosc_graczy, db_logowanie
            correct_steps[1] = True
            host = True
            while True:
                time.sleep(1)
                players = [player for player in db_logowanie.query_active_players()]
                number_of_players = len(players)
                z = 1
                for i in range(number_of_players):
                    if players[i].login == nickname:
                        pass
                    else:
                        player_names[z] = players[i].login
                        z = z + 1
                if number_of_players == ilosc_graczy:
                    break

            self.root.destroy()

        def action_multi_player(self):
            global host, ilosc_graczy, db_logowanie, db_rozgrywka
            host = False
            correct_steps[1] = True
            while True:
                time.sleep(1)
                players = [player for player in db_logowanie.query_active_players()]
                number_of_players = len(players)
                try:
                    result = [obj for obj in db_rozgrywka.query_latest_data(db_rozgrywka.query())][0]
                    if number_of_players == ilosc_graczy and result.akcja_gracza == "INIT":
                        break
                except:
                    pass
            self.root.destroy()

        def action_koniec(self):
            exit(0)

    class Card(object):
        def __init__(self, value, suit):
            self.value = value
            self.suit = suit
            self.showing = True

        def __repr__(self):
            value_name = ""
            suit_name = ""
            if self.showing:
                if self.value == 0:
                    value_name = "Dwa"
                if self.value == 1:
                    value_name = "Trzy"
                if self.value == 2:
                    value_name = "Cztery"
                if self.value == 3:
                    value_name = "Pięć"
                if self.value == 4:
                    value_name = "Sześć"
                if self.value == 5:
                    value_name = "Siedem"
                if self.value == 6:
                    value_name = "Osiem"
                if self.value == 7:
                    value_name = "Dziewięć"
                if self.value == 8:
                    value_name = "Dziesięć"
                if self.value == 9:
                    value_name = "Walet"
                if self.value == 10:
                    value_name = "Dama"
                if self.value == 11:
                    value_name = "Król"
                if self.value == 12:
                    value_name = "As"
                if self.suit == 0:
                    suit_name = "Karo"
                if self.suit == 1:
                    suit_name = "Trefl"
                if self.suit == 2:
                    suit_name = "Kier"
                if self.suit == 3:
                    suit_name = "Pik"
                return value_name + suit_name
            else:
                return "[CARD]"

    def adapter_postgre_cards(karta: str) -> Card:
        wartosc = "brak"
        znak = "brak"
        if karta[-4:] == "Karo":
            wartosc = karta[:-4]
            znak = karta[-4:]
        elif karta[-4:] == "Kier":
            wartosc = karta[:-4]
            znak = karta[-4:]
        elif karta[-5:] == "Trefl":
            wartosc = karta[:-5]
            znak = karta[-5:]
        elif karta[-3:] == "Pik":
            wartosc = karta[:-3]
            znak = karta[-3:]
        if wartosc == "Dwa":
            wartosc = 0
        if wartosc == "Trzy":
            wartosc = 1
        if wartosc == "Cztery":
            wartosc = 2
        if wartosc == "Pięć":
            wartosc = 3
        if wartosc == "Sześć":
            wartosc = 4
        if wartosc == "Siedem":
            wartosc = 5
        if wartosc == "Osiem":
            wartosc = 6
        if wartosc == "Dziewięć":
            wartosc = 7
        if wartosc == "Dziesięć":
            wartosc = 8
        if wartosc == "Walet":
            wartosc = 9
        if wartosc == "Dama":
            wartosc = 10
        if wartosc == "Król":
            wartosc = 11
        if wartosc == "As":
            wartosc = 12
        if znak == "Karo":
            znak = 0
        if znak == "Trefl":
            znak = 1
        if znak == "Kier":
            znak = 2
        if znak == "Pik":
            znak = 3

        return Card(value=wartosc, suit=znak)

    class StandardDeck(list):
        def __init__(self):
            super().__init__()
            suits = list(range(4))
            values = list(range(13))
            [[self.append(Card(i, j)) for j in suits] for i in values]

        def __repr__(self):
            return f"Standard deck of cards\n{len(self)} cards remaining"

        def shuffle(self):
            random.shuffle(self)
            print("\n\n--deck shuffled--")

        def deal(self, location, times=1):
            global db_rozgrywka
            for i in range(times):
                try:
                    location.cards.append(self.pop(0))
                except:
                    pass

        def burn(self):
            self.pop(0)

    class Player(object):
        def __init__(self, name=None):
            self.name = name
            self.chips = 0
            self.stake = 0
            self.stake_gap = 0
            self.cards = []
            self.score = []
            self.fold = False
            self.ready = False
            self.all_in = False
            self.list_of_special_attributes = []
            self.win = False

        def __repr__(self):
            name = self.name
            return name

    class Game(object):
        def __init__(self):
            # DATABASE
            global tekst, HASLO_DO_BAZY_DANYCH

            self.need_raise_info = False
            self.game_over = False
            self.acting_player = Player()
            self.possible_responses = []
            self.round_counter = 0
            self.cards = []
            self.pot = 0
            self.pot_dict = {}
            self.pot_in_play = 0
            self.list_of_player_names = []
            self.dealer = Player()
            self.small_blind = Player()
            self.big_blind = Player()
            self.first_actor = Player()
            self.winners = []
            self.deck = StandardDeck()
            self.list_of_scores_from_eligible_winners = []
            self.setup = ask_app("Start?")
            while True:
                try:
                    self.number_of_players = len(self.setup["players"])
                    break
                except ValueError:
                    print("Invalid response number players")
            if 1 < self.number_of_players < 11:
                pass
            else:
                print("Invalid number of players")
                main()
            self.list_of_players = [Player(name) for name in self.setup["players"] if name != ""]
            if not host:
                while True:
                    try:
                        result = [row for row in db_rozgrywka.query_latest_data(db_rozgrywka.query())][0]
                        if result.akcja_gracza != "INIT":
                            raise Exception
                        self.list_of_players[0].name = result.gracz4_id
                        self.list_of_players[1].name = result.gracz1_id
                        self.list_of_players[2].name = result.gracz2_id
                        self.list_of_players[3].name = result.gracz3_id
                        break
                    except:
                        print("Exception with player assigment")
                        pass
            while True:
                try:
                    self.starting_chips = int(self.setup["chips"][0])
                    if self.starting_chips > 0:
                        break
                    print("Invalid number, try greater than 0")
                except ValueError:
                    print("Invalid response number grater than0")
                    continue
            for player in self.list_of_players:
                player.chips = self.starting_chips
            self.ready_list = []
            while True:
                try:
                    self.small_blind_amount = int(self.setup["chips"][1])
                    if self.starting_chips > self.small_blind_amount > 0:
                        break
                    print("Invalid number: try bigger than zero, smaller than starting chips")
                except ValueError:
                    print("Invalid response bigger than zero chips")
                    continue
            while True:
                try:
                    self.big_blind_amount = int(self.setup["chips"][2])
                    if self.starting_chips > self.big_blind_amount > self.small_blind_amount:
                        break
                    print("Invalid number: try bigger than small blind, smaller than starting chips")
                except ValueError:
                    print("Invalid responsebigger than blind chips")
                    continue
            self.winner = None
            self.action_counter = 0
            self.attribute_list = ["d", "sb", "bb", "fa"]
            self.highest_stake = 0
            self.fold_list = []
            self.not_fold_list = []
            self.round_ended = False
            self.fold_out = False
            self.list_of_scores_eligible = []
            self.list_of_players_not_out = self.list_of_players
            self.number_of_player_not_out = int(len(list(set(self.list_of_players))))

        def print_game_info(self):
            pass

        def print_round_info(self):
            global db_rozgrywka
            print("\n")
            for player in self.list_of_players:
                print("\n")
                print(f"Name: {player.name}")
                print(f"Cards: {player.cards}")
                print(f"Player score: {player.score}")
                print(f"Chips: {player.chips}")
                print(f"Special Attributes: {player.list_of_special_attributes}")
                if player.fold:
                    print(f"Folded")
                if player.all_in:
                    print(f"All-in")
                print(f"Stake: {player.stake}")
                print(f"Stake-gap: {player.stake_gap}")
                print("\n")
            print(f"Pula: {self.pot}")
            print(f"Community cards: {self.cards}")
            print("\n")

        def establish_player_attributes(self):
            address_assignment = 0
            self.dealer = self.list_of_players_not_out[address_assignment]
            self.dealer.list_of_special_attributes.append("dealer")
            address_assignment += 1
            address_assignment %= len(self.list_of_players_not_out)
            self.small_blind = self.list_of_players_not_out[address_assignment]
            self.small_blind.list_of_special_attributes.append("small blind")
            address_assignment += 1
            address_assignment %= len(self.list_of_players_not_out)
            self.big_blind = self.list_of_players_not_out[address_assignment]
            self.big_blind.list_of_special_attributes.append("big blind")
            address_assignment += 1
            address_assignment %= len(self.list_of_players_not_out)
            self.first_actor = self.list_of_players_not_out[address_assignment]
            self.first_actor.list_of_special_attributes.append("first actor")
            self.list_of_players_not_out.append(self.list_of_players_not_out.pop(0))

        def deal_hole(self):
            for player in self.list_of_players_not_out:
                self.deck.deal(player, 2)

        def deal_flop(self):
            self.deck.burn()
            self.deck.deal(self, 3)

        def deal_turn(self):
            self.deck.burn()
            print("\n--card burned--")
            self.deck.deal(self, 1)
            print(f"\nCommunity Cards: {self.cards}")

        def deal_river(self):
            self.deck.burn()
            print("\n--card burned--")
            self.deck.deal(self, 1)
            print(f"\n\nCommunity Cards: {self.cards}")

        def hand_scorer(self, player):
            seven_cards = player.cards + self.cards
            all_hand_combos = list(itertools.combinations(seven_cards, 5))
            list_of_all_score_possibilities = []
            for i in all_hand_combos:
                suit_list = []
                value_list = []
                for j in i:
                    suit_list.append(j.suit)
                    value_list.append(j.value)
                initial_value_check = list(reversed(sorted(value_list)))
                score1 = 0
                score2 = 0
                score3 = 0
                score4 = initial_value_check.pop(0)
                score5 = initial_value_check.pop(0)
                score6 = initial_value_check.pop(0)
                score7 = initial_value_check.pop(0)
                score8 = initial_value_check.pop(0)
                list_of_pair_values = []
                other_cards_not_special = []
                pair_present = False
                pair_value = int
                value_counter = dict(Counter(value_list))
                for value_name, count in value_counter.items():
                    if count == 2:
                        pair_present = True
                        pair_value = value_name
                        list_of_pair_values.append(value_name)
                if pair_present:
                    for value in value_list:
                        if value not in list_of_pair_values:
                            other_cards_not_special.append(value)
                    other_cards_not_special = list(reversed(sorted(other_cards_not_special)))
                    if len(set(list_of_pair_values)) == 1:
                        score1 = 1
                        score2 = max(list_of_pair_values)
                        try:
                            score3 = other_cards_not_special.pop(0)
                            score4 = other_cards_not_special.pop(0)
                            score5 = other_cards_not_special.pop(0)
                            score6 = other_cards_not_special.pop(0)
                            score7 = other_cards_not_special.pop(0)
                            score8 = other_cards_not_special.pop(0)
                        except IndexError:
                            print("Exception with index error 1")
                            pass
                    if len(set(list_of_pair_values)) == 2:
                        list_of_pair_values = list(reversed(sorted(list_of_pair_values)))
                        score1 = 2
                        score2 = list_of_pair_values.pop(0)
                        score3 = list_of_pair_values.pop(0)
                        try:
                            score4 = other_cards_not_special.pop(0)
                            score5 = other_cards_not_special.pop(0)
                            score6 = other_cards_not_special.pop(0)
                            score7 = other_cards_not_special.pop(0)
                            score8 = other_cards_not_special.pop(0)
                        except IndexError:
                            print("Exception with index error 2")
                            pass
                three_of_a_kind_value = int
                other_cards_not_special = []
                three_of_a_kind_present = False
                for value_name, count in value_counter.items():
                    if count == 3:
                        three_of_a_kind_present = True
                        three_of_a_kind_value = value_name
                if three_of_a_kind_present:
                    for value in value_list:
                        if value != three_of_a_kind_value:
                            other_cards_not_special.append(value)
                    other_cards_not_special = list(reversed(sorted(other_cards_not_special)))
                    score1 = 3
                    score2 = three_of_a_kind_value
                    try:
                        score3 = other_cards_not_special.pop(0)
                        score4 = other_cards_not_special.pop(0)
                        score5 = other_cards_not_special.pop(0)
                        score6 = other_cards_not_special.pop(0)
                        score7 = other_cards_not_special.pop(0)
                        score8 = other_cards_not_special.pop(0)
                    except IndexError:
                        print("Exception with index error 3")
                        pass
                if sorted(value_list) == list(range(min(value_list), max(value_list) + 1)):
                    score1 = 4
                    score2 = max(value_list)
                if sorted(value_list) == [0, 1, 2, 3, 12]:
                    score1 = 4
                    score2 = 3
                if len(set(suit_list)) == 1:
                    score1 = 5
                    score2 = max(value_list)
                if three_of_a_kind_present and pair_present:
                    score1 = 6
                    score2 = three_of_a_kind_value
                    score3 = pair_value
                four_of_a_kind_value = int
                other_card_value = int
                four_of_a_kind = False
                for value_name, count in value_counter.items():
                    if count == 4:
                        four_of_a_kind_value = value_name
                        four_of_a_kind: True
                for value in value_list:
                    if value != four_of_a_kind_value:
                        other_card_value = value
                if four_of_a_kind:
                    score1 = 7
                    score2 = four_of_a_kind_value
                    score3 = other_card_value
                if sorted(value_list) == [0, 1, 2, 3, 12] and len(set(suit_list)) == 1:
                    score1 = 8
                    score2 = 3
                if sorted(value_list) == list(range(min(value_list), max(value_list) + 1)) and len(set(suit_list)) == 1:
                    score1 = 8
                    score2 = max(value_list)
                    if max(value_list) == 12:
                        score1 = 9
                list_of_all_score_possibilities.append([score1, score2, score3, score4, score5, score6, score7, score8])
            best_score = max(list_of_all_score_possibilities)
            player.score = best_score

        def score_all(self):
            for player in self.list_of_players_not_out:
                self.hand_scorer(player)

        def find_winners(self):
            global wygrana, twice
            if self.fold_out:
                for player in list(set(self.winners)):
                    player.chips += int((self.pot / len(list(set(self.winners)))))
                    print(f"{player.name} wins {int((self.pot / len(list(set(self.winners)))))} chips!")
            else:
                list_of_stakes = []
                for player in self.list_of_players_not_out:
                    list_of_stakes.append(player.stake)
                list_of_stakes = list(set(list_of_stakes))
                list_of_stakes = sorted(list_of_stakes)
                for stake in list_of_stakes:
                    print(stake)
                for player in self.list_of_players_not_out:
                    print(player.name)
                    print(player.stake)
                print(self.list_of_players_not_out)
                list_of_players_at_stake = []
                list_of_list_of_players_at_stake = []
                for i in range(len(list_of_stakes)):
                    for player in self.list_of_players_not_out:
                        if player.stake >= list_of_stakes[i]:
                            list_of_players_at_stake.append(player)
                    list_of_list_of_players_at_stake.append(list(set(list_of_players_at_stake)))
                    list_of_players_at_stake.clear()
                print(list_of_list_of_players_at_stake)
                list_of_pot_seeds = []
                for i in list_of_stakes:
                    list_of_pot_seeds.append(i)
                list_of_pot_seeds.reverse()
                for i in range(len(list_of_pot_seeds)):
                    try:
                        list_of_pot_seeds[i] -= list_of_pot_seeds[i + 1]
                    except IndexError:
                        pass
                list_of_pot_seeds.reverse()
                list_of_pots = []
                for i in range(len(list_of_pot_seeds)):
                    print(len(list_of_list_of_players_at_stake[i]))
                for i in range(len(list_of_pot_seeds)):
                    list_of_pots.append(list_of_pot_seeds[i] * len(list_of_list_of_players_at_stake[i]))
                for i in range(len(list_of_pots)):
                    winners = []
                    self.list_of_scores_eligible.clear()
                    for player in list_of_list_of_players_at_stake[i]:
                        if player.fold:
                            pass
                        else:
                            self.list_of_scores_eligible.append(player.score)
                    max_score = max(self.list_of_scores_eligible)
                    for player in list_of_list_of_players_at_stake[i]:
                        if player.fold:
                            pass
                        else:
                            if player.score == max_score:
                                player.win = True
                                winners.append(player)
                    prize = int(list_of_pots[i] / len(winners))
                    for player in winners:
                        print(f"{player.name} wins {prize} chips!")
                        player.chips += prize
                        self.pot -= prize
                for player in self.list_of_players_not_out:
                    if player.win:
                        print(
                            "\n" + player.name + ": " + str(
                                player.cards) + "\t<-WINNER WINNER WINNER WINNER WINNER WINNER "
                                                "WINNER WINNER" + "\n\t" + score_interpreter(player))
                        wygrana = True
                    elif player.fold:
                        print("\n" + player.name + ": " + str(player.cards) + "\n\t" + "[FOLDED]")
                    else:
                        print("\n" + player.name + ": " + str(player.cards) + "\n\t" + score_interpreter(player))
                    print(f"\tScoreCode: {player.score}")
                    print(f"Pula: {self.pot}")
                [print(player.name, player.chips) for player in self.list_of_players_not_out]

        def clear_board(self):
            self.possible_responses.clear()
            self.cards.clear()
            self.deck = StandardDeck()
            self.deck.shuffle()
            print(self.deck)
            self.pot = 0
            self.pot_dict.clear()
            self.winners.clear()
            self.list_of_scores_from_eligible_winners.clear()
            self.action_counter = 0
            self.highest_stake = 0
            self.fold_list.clear()
            self.not_fold_list.clear()
            self.fold_out = False
            self.list_of_scores_eligible.clear()
            self.round_ended = False
            for player in self.list_of_players:
                player.score.clear()
                player.cards.clear()
                player.stake = 0
                player.stake_gap = 0
                player.ready = False
                player.all_in = False
                player.fold = False
                player.list_of_special_attributes.clear()
                player.win = False

        def end_round(self):
            global wygrana, once
            self.list_of_players_not_out = list(set(self.list_of_players_not_out))
            for player in self.list_of_players_not_out:
                if player.chips <= 0:
                    self.list_of_players_not_out.remove(player)
                    print(f"{player.name} is out of the game!")
            self.number_of_player_not_out = len(set(self.list_of_players_not_out))
            if self.number_of_player_not_out == 1:
                self.game_over = True
                self.winner = self.list_of_players_not_out[0]
                print(f"Game is over: {self.winner} wins with {self.winner.chips}!")
            new_round = str(ask_app("Start a new round? (yes/no)"))
            if new_round == "yes":
                once = True
                wygrana = False
                print("\n\n\t\t\t\t--ROUND OVER--")
                print("\n\n\t\t\t--STARTING NEW ROUND--\n")
                self.round_counter += 1
                pass
            time.sleep(0.3)
            # self.clear_board()

        def answer(self, player):
            global flop, all_in
            global tekst, actual_player, db_rozgrywka
            player.stake_gap = self.highest_stake - player.stake
            if player.all_in or player.fold or self.fold_out:
                return True
            if player.chips <= 0:
                print(f"{player.name} is all in!")
                player.all_in = True
            print(f"Highest stake: {self.highest_stake}")
            print(f"Put in at least {player.stake_gap} to stay in.\nDon't Have that much? You'll have to go all-in!")
            print(f"Chips available: {player.chips}")
            self.possible_responses.clear()
            all_in = False
            if player.stake_gap > 0:
                flop = False
                self.possible_responses.append("Fold")
                if player.stake_gap == player.chips:
                    self.possible_responses.append("All in")

                if player.stake_gap > player.chips:
                    all_in = True
                    self.possible_responses.append("All in")
                if player.stake_gap < player.chips:
                    self.possible_responses.append("Call")
                    self.possible_responses.append("Raise")
                    self.possible_responses.append("All in")
            if player.stake_gap == 0:
                flop = True
                self.possible_responses.append("Check")
                self.possible_responses.append("Raise")
                self.possible_responses.append("Fold")
                self.possible_responses.append("All in")
            while True:
                response = str(ask_app(f"{player}'s action\n->", self))
                if response not in self.possible_responses and not response.isdigit():
                    continue
                if response == "All in":
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "All in",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " gra All-in!"
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)
                    player.stake += player.chips
                    self.pot += player.chips
                    player.stake_gap -= player.chips
                    player.chips = 0
                    print(f"{player.name} is all-in!")
                    player.all_in = True
                    return True
                if response == "All in":
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "All in",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " gra All-in!"
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)

                    print(f"{player.name} is all-in!")
                    player.all_in = True
                    player.stake += player.stake_gap
                    self.pot += player.stake_gap
                    player.chips = 0
                    player.stake_gap = 0
                    return True
                if response == "Fold":
                    player.fold = True
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "Fold",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " folduje!"
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)

                    self.fold_list.append(player)

                    if len(self.fold_list) == (len(self.list_of_players_not_out) - 1):
                        for player in self.list_of_players_not_out:
                            if player not in self.fold_list:
                                self.fold_out = True
                                print(f"{player} wins!")
                                self.winners.append(player)
                                for player in self.winners:
                                    player.win = True
                                self.round_ended = True
                    return True
                if response == "Call":
                    player.stake += player.stake_gap
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "Call",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " calluje."
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)

                    self.pot += player.stake_gap
                    player.chips -= player.stake_gap
                    player.stake_gap = 0
                    return True
                if response == "Check":
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "Check",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " sprawdza."
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)

                    player.stake_gap = 0
                    return True
                if response == "Raise" or response.isdigit():
                    self.need_raise_info = True
                    while True:
                        if response.isdigit():
                            bet = int(response) + player.stake_gap
                        else:
                            bet = int(
                                ask_app(f"How much would {player.name} like to raise? ({player.chips} available)\n->",
                                        self) + player.stake_gap)
                        if bet > player.chips or bet <= 0:
                            print("Invalid response bout raising 1")
                            continue
                        if bet == player.chips:
                            print(f"{player.name} is all-in!")
                            player.all_in = True
                        self.need_raise_info = False
                        player.stake += bet
                        self.pot += bet
                        player.chips -= bet
                        self.highest_stake = player.stake
                        self.ready_list.clear()
                        player.stake_gap = 0
                        if not z_bazy:
                            db_rozgrywka.insert(self.round_counter, self.acting_player.name, f"Raise {int(response)}",
                                                [str(karta) for karta in self.cards],
                                                self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                                str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                                self.list_of_players[0].stake, 0,
                                                self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                                str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                                self.list_of_players[1].stake, 0,
                                                self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                                str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                                self.list_of_players[2].stake, 0,
                                                self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                                str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                                self.list_of_players[3].stake, 0, )
                        tekst = str(self.acting_player.name) + " podnosi stawkę."
                        update_log(tekst)
                        tekst = "Ilość żetonów na stole: " + str(self.pot)
                        update_log(tekst)
                        return True
                if response == "Raise" or response.isdigit():

                    self.need_raise_info = True
                    player.stake += player.stake_gap
                    self.pot += player.stake_gap
                    player.chips -= player.stake_gap
                    player.stake_gap = 0
                    while True:
                        try:
                            if response.isdigit():
                                bet = int(response) + player.stake_gap
                            else:
                                bet = int(
                                    ask_app(
                                        f"How much would {player.name} like to raise? ({player.chips} available)\n->",
                                        self) + player.stake_gap)
                        except ValueError:
                            continue
                        if bet > player.chips or bet <= 0:
                            print("Invalid response bout raisin 2")
                            continue
                        if bet == player.chips:
                            print(f"{player.name} is all-in!")
                            player.all_in = True
                        self.need_raise_info = False
                        player.stake += bet
                        self.pot += bet
                        player.chips -= bet
                        self.highest_stake = player.stake
                        self.ready_list.clear()

                        tekst = str(self.acting_player.name) + " podnosi stawkę o " + str(bet) + "."
                        update_log(tekst)
                        tekst = "Ilość żetonów na stole: " + str(self.pot)
                        update_log(tekst)
                        if not z_bazy:
                            db_rozgrywka.insert(self.round_counter, self.acting_player.name, f"Raise {int(response)}",
                                                [str(karta) for karta in self.cards],
                                                self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                                str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                                self.list_of_players[0].stake, 0,
                                                self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                                str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                                self.list_of_players[1].stake, 0,
                                                self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                                str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                                self.list_of_players[2].stake, 0,
                                                self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                                str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                                self.list_of_players[3].stake, 0, )
                        return True
                if response == "All in":
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "All in",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " gra All-in!"
                    update_log(tekst)
                    tekst = "Ilość żetonów na stole: " + str(self.pot)
                    update_log(tekst)

                    player.stake += player.stake_gap
                    self.pot += player.stake_gap
                    player.chips -= player.stake_gap
                    player.stake_gap = 0
                    player.stake += player.chips
                    self.pot += player.chips
                    player.stake_gap -= player.chips
                    player.chips = 0
                    print(f"{player.name} is all-in!")
                    player.all_in = True
                    self.highest_stake = player.stake
                    self.ready_list.clear()
                    return True
                if response == "All in":
                    if not z_bazy:
                        db_rozgrywka.insert(self.round_counter, self.acting_player.name, "All in",
                                            [str(karta) for karta in self.cards],
                                            self.list_of_players[0].name, 0, str(self.list_of_players[0].cards[0]),
                                            str(self.list_of_players[0].cards[1]), self.list_of_players[0].chips,
                                            self.list_of_players[0].stake, 0,
                                            self.list_of_players[1].name, 0, str(self.list_of_players[1].cards[0]),
                                            str(self.list_of_players[1].cards[1]), self.list_of_players[1].chips,
                                            self.list_of_players[1].stake, 0,
                                            self.list_of_players[2].name, 0, str(self.list_of_players[2].cards[0]),
                                            str(self.list_of_players[2].cards[1]), self.list_of_players[2].chips,
                                            self.list_of_players[2].stake, 0,
                                            self.list_of_players[3].name, 0, str(self.list_of_players[3].cards[0]),
                                            str(self.list_of_players[3].cards[1]), self.list_of_players[3].chips,
                                            self.list_of_players[3].stake, 0, )
                    tekst = str(self.acting_player.name) + " gra All-in!"
                    actual_player = self.acting_player.name
                    player.stake_gap = 0
                    player.stake += player.chips
                    self.pot += player.chips
                    player.chips = 0
                    print(f"{player.name} is all-in!")
                    player.all_in = True
                    self.highest_stake = player.stake
                    self.ready_list.clear()
                    return True
                print("Invalid Response ogolem")

        def ask_players(self):
            self.ready_list.clear()
            '''
            for i in range(3):
                self.list_of_players_not_out.append(self.list_of_players_not_out[0])
                self.list_of_players_not_out.pop(0)
            '''
            starting_index = self.list_of_players_not_out.index(self.first_actor)
            for player in self.list_of_players_not_out:
                player.ready = False
            while True:
                self.acting_player = self.list_of_players_not_out[starting_index]
                player_ready = self.answer(self.list_of_players_not_out[starting_index])
                starting_index += 1
                starting_index %= len(self.list_of_players_not_out)
                if player_ready:
                    self.ready_list.append("gogo")
                if len(self.ready_list) == len(self.list_of_players_not_out):
                    break

        def act_one(self):
            if self.small_blind_amount > self.small_blind.chips:
                self.small_blind.stake += self.small_blind.chips
                self.highest_stake = self.small_blind.chips
                self.pot += self.small_blind.chips
                self.small_blind.chips = 0
                print(f"{self.small_blind.name} is all-in!")
                self.small_blind.all_in = True
            else:
                self.small_blind.chips -= self.small_blind_amount
                self.small_blind.stake += self.small_blind_amount
                self.highest_stake = self.small_blind_amount
                self.pot += self.small_blind_amount
            if self.big_blind_amount > self.big_blind.chips:
                self.big_blind.stake += self.big_blind.chips
                self.highest_stake = self.big_blind.chips
                self.pot += self.big_blind.chips
                self.big_blind.chips = 0
                print(f"{self.big_blind} is all-in!")
                self.big_blind.all_in = True
            else:
                self.big_blind.chips -= self.big_blind_amount
                self.big_blind.stake += self.big_blind_amount
                self.highest_stake = self.big_blind_amount
                self.pot += self.big_blind_amount
            self.ask_players()

    class App(Tk):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.game_object = object
            setup = {
                "players": player_names,
                "chips": ['200', '5', '10']
            }
            response_q.put(setup)
            game_event.set()
            container = Frame(self)
            container.pack(side="top", fill="both", expand=True)
            container.grid_rowconfigure(0, weight=1)
            container.grid_columnconfigure(0, weight=1)

            self.frames = {GamePage: GamePage(container, self)}
            self.frames[GamePage].grid(row=0, column=0, sticky="nsew")
            self.fresh = True
            self.show_frame(GamePage)

        def show_frame(self, context):
            frame = self.frames[context]
            print("waiting")
            if not self.fresh:
                time.sleep(0.1)
                frame.update(game_info_q.get())
            self.fresh = False
            frame.tkraise()

    class GamePage(Frame):

        def __init__(self, parent, controller):
            Frame.__init__(self, parent)

            global tekst, button0, button1, button2, button3, button4, akcja, twice, all_in
            self.restart = False
            self.responses = []
            self.list_of_button_r = []
            self.winfo_toplevel().title("Texas Hold'em - ekran gry")
            self.winfo_toplevel().state("zoomed")
            height = 1100
            width = 1920
            canvas = Canvas(self, height=height, width=width, bg='green')
            canvas.pack()

            left_frame = Frame(canvas, bg='green', bd=5)
            left_frame.place(relx=0, rely=0, relwidth=0.8, relheight=1, anchor='nw')
            name_frame = Frame(left_frame, bg="light green", bd=5)
            name_frame.place(relx=0.5, rely=0, relwidth=1, relheight=1, anchor="n")

            self.frame_p0 = Frame(name_frame, bd=3, relief="groove")
            self.frame_p0.place(relx=0, rely=-0.002, relwidth=0.5, relheight=0.17)
            self.name_label_p0 = Label(self.frame_p0, font=("Calibri", 18), bd=3)
            self.name_label_p0.place(relx=0, rely=0, relheight=(1 / 3), relwidth=0.38)
            self.chips_label_p0 = Label(self.frame_p0, font=("Calibri", 18), bd=3)
            self.chips_label_p0.place(relx=0, rely=(1 / 3), relheight=(1 / 3), relwidth=0.38)
            self.cards_frame_p0 = Frame(self.frame_p0, bd=3, relief="groove")
            self.cards_frame_p0.place(relx=0.38, relheight=1, relwidth=0.62)
            self.card1_p0 = Label(self.cards_frame_p0)
            self.card1_p0.place(relwidth=0.7, relheight=1)
            self.card2_p0 = Label(self.cards_frame_p0)
            self.card2_p0.place(relx=0.5, relwidth=0.4, relheight=1)
            self.stake_label_p0 = Label(self.frame_p0, font=("Calibri", 18), bd=1, relief="groove")
            self.stake_label_p0.place(relx=0, rely=(2 / 3), relheight=(1 / 3), relwidth=0.38)

            self.frame_p1 = Frame(name_frame, bd=3, relief="groove")
            self.frame_p1.place(relx=0.5, rely=-0.002, relwidth=0.5, relheight=0.17)
            self.name_label_p1 = Label(self.frame_p1, font=("Calibri", 18), bd=3)
            self.name_label_p1.place(relx=0, rely=0, relheight=(1 / 3), relwidth=0.38)
            self.chips_label_p1 = Label(self.frame_p1, font=("Calibri", 18), bd=3)
            self.chips_label_p1.place(relx=0, rely=(1 / 3), relheight=(1 / 3), relwidth=0.38)
            self.cards_frame_p1 = Frame(self.frame_p1, bd=3, relief="groove")
            self.cards_frame_p1.place(relx=0.38, relheight=1, relwidth=0.62)
            self.card1_p1 = Label(self.cards_frame_p1)
            self.card1_p1.place(relwidth=0.7, relheight=1)
            self.card2_p1 = Label(self.cards_frame_p1)
            self.card2_p1.place(relx=0.5, relwidth=0.4, relheight=1)
            self.stake_label_p1 = Label(self.frame_p1, font=("Calibri", 18), bd=1, relief="groove")
            self.stake_label_p1.place(relx=0, rely=(2 / 3), relheight=(1 / 3), relwidth=0.38)

            self.frame_p2 = Frame(name_frame, bd=3, relief="groove")
            self.frame_p2.place(relx=0, rely=0.635, relwidth=0.5, relheight=0.17)
            self.name_label_p2 = Label(self.frame_p2, font=("Calibri", 18), bd=3)
            self.name_label_p2.place(relx=0, rely=0, relheight=(1 / 3), relwidth=0.38)
            self.chips_label_p2 = Label(self.frame_p2, font=("Calibri", 18), bd=3)
            self.chips_label_p2.place(relx=0, rely=(1 / 3), relheight=(1 / 3), relwidth=0.38)
            self.cards_frame_p2 = Frame(self.frame_p2, bd=3, relief="groove")
            self.cards_frame_p2.place(relx=0.38, relheight=1, relwidth=0.62)
            self.card1_p2 = Label(self.cards_frame_p2)
            self.card1_p2.place(relwidth=0.7, relheight=1)
            self.card2_p2 = Label(self.cards_frame_p2)
            self.card2_p2.place(relx=0.5, relwidth=0.4, relheight=1)
            self.stake_label_p2 = Label(self.frame_p2, font=("Calibri", 18), bd=1, relief="groove")
            self.stake_label_p2.place(relx=0, rely=(2 / 3), relheight=(1 / 3), relwidth=0.38)

            self.frame_p3 = Frame(name_frame, bd=3, relief="groove")
            self.frame_p3.place(relx=0.5, rely=0.635, relwidth=0.5, relheight=0.17)
            self.name_label_p3 = Label(self.frame_p3, font=("Calibri", 18), bd=3)
            self.name_label_p3.place(relx=0, rely=0, relheight=(1 / 3), relwidth=0.38)
            self.chips_label_p3 = Label(self.frame_p3, font=("Calibri", 18), bd=3)
            self.chips_label_p3.place(relx=0, rely=(1 / 3), relheight=(1 / 3), relwidth=0.38)
            self.cards_frame_p3 = Frame(self.frame_p3, bd=3, relief="groove")
            self.cards_frame_p3.place(relx=0.38, relheight=1, relwidth=0.62)
            self.card1_p3 = Label(self.cards_frame_p3)
            self.card1_p3.place(relwidth=0.7, relheight=1)
            self.card2_p3 = Label(self.cards_frame_p3)
            self.card2_p3.place(relx=0.5, relwidth=0.4, relheight=1)
            self.stake_label_p3 = Label(self.frame_p3, font=("Calibri", 18), bd=1, relief="groove")
            self.stake_label_p3.place(relx=0, rely=(2 / 3), relheight=(1 / 3), relwidth=0.38)

            right_frame = Frame(canvas, bg='green', bd=5)
            right_frame.place(relx=1, rely=0, relwidth=0.2, relheight=0.8, anchor='ne')
            '''self.cc_frame = Frame(left_frame, bg='black')
            self.cc_frame.place(relx=0, rely=0.5, relwidth=1, relheight=0.1)

            '''
            self.cc_frame = Frame(left_frame, bg='black')
            self.cc_frame.place(relx=0, rely=0.175, relwidth=1, relheight=0.46)

            self.stol = Label(self.cc_frame, bg="red")
            stol_d1 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/stol.png")).resize((1920, 980), Image.ANTIALIAS))
            self.stol.image = stol_d1
            self.stol.configure(image=stol_d1)
            self.stol.place(relx=0, rely=0, relwidth=1, relheight=1)

            '''
            self.stol_frame = Frame(canvas, bg='blue',bd=2)
            self.stol_frame.place(relx=0, rely=0.21, relwidth=0.5, relheight=0.39)

            self.stol_1 = Label(self.stol_frame, bg="red")
            self.stol_1.place(relwidth=1, relheight=1)

            stol_d1 = ImageTk.PhotoImage(
                Image.open("cards/stol.png").resize((975, 680), Image.ANTIALIAS))
            self.stol_1.image = stol_d1
            self.stol_1.configure(image=stol_d1)

            '''
            cards_width = 0.054
            cards_height = 0.230
            self.cc_1 = Label(self.cc_frame, bg="green")
            self.cc_1.place(relx=0.27, rely=0.38, relwidth=cards_width, relheight=cards_height)
            card_d1 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
            self.cc_1.image = card_d1
            self.cc_1.configure(image=card_d1)

            self.cc_2 = Label(self.cc_frame, bg="green")
            self.cc_2.place(relx=0.37, rely=0.38, relwidth=cards_width, relheight=cards_height)
            card_d2 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
            self.cc_2.image = card_d2
            self.cc_2.configure(image=card_d2)

            self.cc_3 = Label(self.cc_frame, bg="green")
            self.cc_3.place(relx=0.47, rely=0.38, relwidth=cards_width, relheight=cards_height)
            card_d3 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
            self.cc_3.image = card_d3
            self.cc_3.configure(image=card_d3)

            self.cc_4 = Label(self.cc_frame, bg="green")
            self.cc_4.place(relx=0.57, rely=0.38, relwidth=cards_width, relheight=cards_height)
            card_d4 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
            self.cc_4.image = card_d4
            self.cc_4.configure(image=card_d4)

            self.cc_5 = Label(self.cc_frame, bg="green")
            self.cc_5.place(relx=0.67, rely=0.38, relwidth=cards_width, relheight=cards_height)
            card_d5 = ImageTk.PhotoImage(
                Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
            self.cc_5.image = card_d5
            self.cc_5.configure(image=card_d5)

            self.pot_label = Label(left_frame, text="Pula: ", font=("Calibri", 15), anchor="w")
            self.pot_label.place(relx=0.91, rely=0.594, relwidth=0.09, relheight=0.04)

            self.right_frame = Frame(right_frame, bd=2, bg="green")
            self.right_frame.place(rely=0.5, relwidth=1, relheight=0.5)
            self.right_frame_label = Label(self.right_frame, bg="green")
            self.right_frame_label.place(relx=0, rely=0, relheight=1, relwidth=1)

            self.actor_label = Label(left_frame, text="Tura gracza: ", font=("Calibri", 13), bd=3, anchor="w")
            self.actor_label.place(relx=0.0009, rely=0.1754, relwidth=0.2, relheight=0.03)
            button0 = Button(right_frame, text="Call", font=("Calibri", 15), bd=3,
                             command=lambda: self.action_input("Call"))
            button0.place(relx=0.20, rely=0.10, relheight=0.10, relwidth=0.65, anchor="sw")
            akcja = self.action_input

            button1 = Button(right_frame, text="Raise", font=("Calibri", 16), bd=3,
                             command=lambda: self.action_input(self.raise_entry.get()))
            button1.place(relx=0.5, rely=0.22, relheight=0.12, relwidth=0.50, anchor="sw")

            button2 = Button(right_frame, text="Fold", font=("Calibri", 16), bd=3, fg='white', bg='blue',
                             command=lambda: self.action_input("Fold"))
            button2.place(relx=0.20, rely=0.32, relheight=0.10, relwidth=0.65, anchor="sw")

            button3 = Button(right_frame, text="All in", font=("Calibri", 16), bd=3, fg='white', bg='red',
                             command=lambda: self.action_input("All in"))
            button3.place(relx=0.20, rely=0.42, relheight=0.10, relwidth=0.65, anchor="sw")

            button4 = Button(right_frame, text="Check", font=("Calibri", 16), bd=3,
                             command=lambda: self.action_input("Check"))
            button4.place(relx=0.20, rely=0.52, relheight=0.10, relwidth=0.65, anchor="sw")

            if all_in:
                button0.visible = False
                button0.place_forget()
                button4.visible = False
                button4.place_forget()
                button1.visible = False
                button1.place_forget()
                button2.visible = True
                button2.place(relx=0.20, rely=0.32, relheight=0.10, relwidth=0.65, anchor="sw")
                button3.visible = True
                button3.place(relx=0.20, rely=0.42, relheight=0.10, relwidth=0.65, anchor="sw")
            else:
                if button0 is not None:
                    button1.visible = True
                    button1.place(relx=0.5, rely=0.22, relheight=0.12, relwidth=0.50, anchor="sw")
                    if flop:
                        button0.visible = False
                        button0.place_forget()
                        button4.visible = True
                        button4.place(relx=0.20, rely=0.10, relheight=0.10, relwidth=0.65, anchor="sw")
                    else:
                        button4.visible = False
                        button4.place_forget()
                        button0.visible = True
                        button0.place(relx=0.20, rely=0.10, relheight=0.10, relwidth=0.65, anchor="sw")

            # self.new_round_label = Label(right_frame, text="Powrót do menu", font=("Calibri", 16), bd=3)
            # self.new_round_label.place(relx=0.275, rely=0.75, relheight=0.10, relwidth=0.5)
            # self.new_round_label.forget()
            # self.button_y = Button(right_frame, text="tak", bg='green', font=("Calibri", 14), bd=5,
            #                        command=lambda: self.action_input("no"))
            # self.button_y.place(relx=0.275, rely=0.85, relheight=0.15, relwidth=0.25)
            # self.button_y.place_forget()
            self.button_n = Button(right_frame, text="nie", bg='yellow', font=("Calibri", 14), bd=5,
                                   command=lambda: self.action_input("no"))
            self.button_n.place(relx=0.529, rely=0.85, relheight=0.15, relwidth=0.25)
            self.button_n.place_forget()
            self.button_menu = Button(right_frame, text="nie", bg='yellow', font=("Calibri", 14), bd=5,
                                      command=lambda: self.action_input("menu"))
            # self.button_y.place(relx=0.275, rely=0.85, relheight=0.15, relwidth=0.5)

            self.raise_entry = Entry(right_frame, font=("Calibri", 16), bd=3, bg='white')
            self.raise_entry.place(relx=-0.01, rely=0.218, relheight=0.119, relwidth=0.5, anchor="sw")
            self.raise_button = Button(right_frame, text="Raise", font=("Calibri", 16), bd=3,
                                       command=lambda: self.action_input(self.raise_entry.get()))
            self.raise_button.place(relx=0.3, rely=1, relheight=0.12, relwidth=0.22, anchor="sw")
            self.raise_button.place_forget()

            self.winner_label = Label(right_frame, font=("Calibri", 16), bd=3, bg='yellow')
            self.winner_label.place(relx=0.01, rely=0.53, relwidth=0.98, relheight=0.20)

            self.log_frame = Frame(canvas, bg='green', bd=5)
            self.log_frame.place(relx=0, rely=0.8, relwidth=1.0, relheight=0.2, anchor='nw')

            self.log_label1 = Label(self.log_frame, text="Log wiersz 1", font=("Calibri", 12), bd=3, anchor="w")
            self.log_label1.place(rely=0.1, relwidth=1, relheight=0.2, anchor='w')
            self.log_label2 = Label(self.log_frame, text="Log wiersz 2", font=("Calibri", 12), bd=3, anchor="w")
            self.log_label2.place(rely=0.3, relwidth=1, relheight=0.2, anchor='w')
            self.log_label3 = Label(self.log_frame, text="Log wiersz 3", font=("Calibri", 12), bd=3, anchor="w")
            self.log_label3.place(rely=0.4, relwidth=1, relheight=0.2)
            self.log_label4 = Label(self.log_frame, text="Log wiersz 4", font=("Calibri", 12), bd=3, anchor="w")
            self.log_label4.place(rely=0.6, relwidth=1, relheight=0.2)
            self.log_label5 = Label(self.log_frame, text="Log wiersz 5", font=("Calibri", 12), bd=3, anchor="w")
            self.log_label5.place(rely=0.8, relwidth=1, relheight=0.2)

            if twice == 1:
                twice = 0
                akcja('yes')

        def update(self, game, right_frame=None):
            global nickname
            global tekst
            global log_list
            global button0
            global button1
            global button2, button3, button4, all_in
            global flop, akcja, twice, actual_player, wygrana, db_rozgrywka, dek, host, once
            self.log_label1['text'] = log_list[4]
            self.log_label2['text'] = log_list[3]
            self.log_label3['text'] = log_list[2]
            self.log_label4['text'] = log_list[1]
            self.log_label5['text'] = log_list[0]
            if twice == 0 and host and once:
                once = False
                db_rozgrywka.insert(0, game.acting_player.name, "INIT", [_ for _ in dek],
                                    game.list_of_players[0].name, 0, str(game.list_of_players[0].cards[0]),
                                    str(game.list_of_players[0].cards[1]), game.list_of_players[0].chips,
                                    game.list_of_players[0].stake, 0,
                                    game.list_of_players[1].name, 0, str(game.list_of_players[1].cards[0]),
                                    str(game.list_of_players[1].cards[1]), game.list_of_players[1].chips,
                                    game.list_of_players[1].stake, 0,
                                    game.list_of_players[2].name, 0, str(game.list_of_players[2].cards[0]),
                                    str(game.list_of_players[2].cards[1]), game.list_of_players[2].chips,
                                    game.list_of_players[2].stake, 0,
                                    game.list_of_players[3].name, 0, str(game.list_of_players[3].cards[0]),
                                    str(game.list_of_players[3].cards[1]), game.list_of_players[3].chips,
                                    game.list_of_players[3].stake, 0)
            if all_in and button1 is not None and button4 is not None:
                button0.visible = False
                button0.place_forget()
                button4.visible = False
                button4.place_forget()
                button1.visible = False
                button1.place_forget()
                button2.visible = True
                button2.place(relx=0.20, rely=0.32, relheight=0.10, relwidth=0.65, anchor="sw")
                button3.visible = True
                button3.place(relx=0.20, rely=0.42, relheight=0.10, relwidth=0.65, anchor="sw")
            else:
                if button0 is not None:
                    button1.visible = True
                    button1.place(relx=0.5, rely=0.22, relheight=0.12, relwidth=0.50, anchor="sw")
                    if flop:
                        button0.visible = False
                        button0.place_forget()
                        button4.visible = True
                        button4.place(relx=0.20, rely=0.10, relheight=0.10, relwidth=0.65, anchor="sw")
                    else:
                        button4.visible = False
                        button4.place_forget()
                        button0.visible = True
                        button0.place(relx=0.20, rely=0.10, relheight=0.10, relwidth=0.65, anchor="sw")

            # self.new_round_label.lower(self.right_frame_label)
            # self.button_y.lower(self.right_frame_label)
            self.button_n.lower(self.right_frame_label)
            self.raise_entry.lower(self.right_frame_label)
            self.raise_button.lower(self.right_frame_label)
            self.winner_label.lower(self.right_frame_label)

            if self.restart:
                card1 = ImageTk.PhotoImage(
                    Image.open(str(resource_path("Karty/default0.png"))).resize((82, 115), Image.ANTIALIAS))
                self.cc_1.image = card1
                self.cc_1.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(str(resource_path("Karty/default0.png"))).resize((82, 115), Image.ANTIALIAS))
                self.cc_2.image = card1
                self.cc_2.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(str(resource_path("Karty/default0.png"))).resize((82, 115), Image.ANTIALIAS))
                self.cc_3.image = card1
                self.cc_3.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(str(resource_path("Karty/default0.png"))).resize((82, 115), Image.ANTIALIAS))
                self.cc_4.image = card1
                self.cc_4.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(str(resource_path("Karty/default0.png"))).resize((82, 115), Image.ANTIALIAS))
                self.cc_5.image = card1
                self.cc_5.configure(image=card1)
                self.restart = False
            if game.round_ended:
                try:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.cards[0]) + ".png")).resize((82, 115),
                                                                                                  Image.ANTIALIAS))
                    self.cc_1.image = card1
                    self.cc_1.configure(image=card1)

                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.cards[1]) + ".png")).resize((82, 115),
                                                                                                  Image.ANTIALIAS))
                    self.cc_2.image = card1
                    self.cc_2.configure(image=card1)

                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.cards[2]) + ".png")).resize((82, 115),
                                                                                                  Image.ANTIALIAS))
                    self.cc_3.image = card1
                    self.cc_3.configure(image=card1)

                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.cards[3]) + ".png")).resize((82, 115),
                                                                                                  Image.ANTIALIAS))
                    self.cc_4.image = card1
                    self.cc_4.configure(image=card1)

                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.cards[4]) + ".png")).resize((82, 115),
                                                                                                  Image.ANTIALIAS))
                    self.cc_5.image = card1
                    self.cc_5.configure(image=card1)
                except IndexError:
                    pass
                time.sleep(0.3)
                # self.new_round_label.lift(self.right_frame_label)
                # self.button_y.lift(self.right_frame_label)
                self.button_n.lift(self.right_frame_label)
                winners = []
                scores = []
                for player in game.list_of_players_not_out:
                    if player.win:
                        winners.append(player)
                        scores.append(player.score)
                print(f"gui thinks winners are: {winners}")
                print(f"and thinks scores are: {scores}")
                if scores == [[]]:
                    self.winner_label["text"] = "Zwycięzca: " + str(winners)

                else:
                    try:
                        for player in game.list_of_players_not_out:
                            if player.win:
                                if player.score == max(scores):
                                    self.winner_label["text"] = "Zwycięzca: " + str(winners) + "\n" + score_interpreter(
                                        player)
                                    update_log(str("Zwycięzca: " + str(winners) + " " + score_interpreter(player)))
                    except IndexError:
                        pass
                self.winner_label.lift(self.right_frame_label)

                self.restart = True
                # twice = 0
                try:
                    if game.list_of_players[0].name == nickname or wygrana:
                        card1 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[0].cards[0]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card1 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card1_p0.image = card1
                    self.card1_p0.configure(image=card1)

                    if game.list_of_players[1].name == nickname or wygrana:
                        card1 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[1].cards[0]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card1 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card1_p1.image = card1
                    self.card1_p1.configure(image=card1)

                    if game.list_of_players[2].name == nickname or wygrana:
                        card1 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[2].cards[0]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card1 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card1_p2.image = card1
                    self.card1_p2.configure(image=card1)

                    if game.list_of_players[3].name == nickname or wygrana:
                        card1 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[3].cards[0]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card1 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card1_p3.image = card1
                    self.card1_p3.configure(image=card1)

                except IndexError:
                    pass
                try:
                    if game.list_of_players[0].name == nickname or wygrana:
                        card2 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[0].cards[1]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card2 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card2_p0.image = card2
                    self.card2_p0.configure(image=card2)

                    if game.list_of_players[1].name == nickname or wygrana:
                        card2 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[1].cards[1]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card2 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card2_p1.image = card2
                    self.card2_p1.configure(image=card2)

                    if game.list_of_players[2].name == nickname or wygrana:
                        card2 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[2].cards[1]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card2 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card2_p2.image = card2
                    self.card2_p2.configure(image=card2)

                    if game.list_of_players[3].name == nickname or wygrana:
                        card2 = ImageTk.PhotoImage(
                            Image.open(
                                resource_path("Karty\\" + str(game.list_of_players[3].cards[1]) + ".png")).resize(
                                (82, 115),
                                Image.ANTIALIAS))
                    else:
                        card2 = ImageTk.PhotoImage(
                            Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                    self.card2_p3.image = card2
                    self.card2_p3.configure(image=card2)

                except IndexError:
                    pass

                return
            if game.need_raise_info:
                self.raise_entry.lift(self.right_frame_label)
                self.raise_button.lift(self.right_frame_label)
            try:
                card1 = ImageTk.PhotoImage(
                    Image.open(resource_path("Karty\\" + str(game.cards[0]) + ".png")).resize((82, 115),
                                                                                              Image.ANTIALIAS))
                self.cc_1.image = card1
                self.cc_1.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(resource_path("Karty\\" + str(game.cards[1]) + ".png")).resize((82, 115),
                                                                                              Image.ANTIALIAS))
                self.cc_2.image = card1
                self.cc_2.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(resource_path("Karty\\" + str(game.cards[2]) + ".png")).resize((82, 115),
                                                                                              Image.ANTIALIAS))
                self.cc_3.image = card1
                self.cc_3.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(resource_path("Karty\\" + str(game.cards[3]) + ".png")).resize((82, 115),
                                                                                              Image.ANTIALIAS))
                self.cc_4.image = card1
                self.cc_4.configure(image=card1)

                card1 = ImageTk.PhotoImage(
                    Image.open(resource_path("Karty\\" + str(game.cards[4]) + ".png")).resize((82, 115),
                                                                                              Image.ANTIALIAS))
                self.cc_5.image = card1
                self.cc_5.configure(image=card1)
            except IndexError:
                pass
            try:
                self.name_label_p0["text"] = game.list_of_players[0]
                self.name_label_p1["text"] = game.list_of_players[1]
                self.name_label_p2["text"] = game.list_of_players[2]
                self.name_label_p3["text"] = game.list_of_players[3]
            except IndexError:
                pass
            try:
                self.chips_label_p0["text"] = "Żetony:\n" + str(game.list_of_players[0].chips)
                self.chips_label_p1["text"] = "Żetony:\n" + str(game.list_of_players[1].chips)
                self.chips_label_p2["text"] = "Żetony:\n" + str(game.list_of_players[2].chips)
                self.chips_label_p3["text"] = "Żetony:\n" + str(game.list_of_players[3].chips)
            except IndexError:
                pass
            try:
                if game.list_of_players[0].name == nickname or wygrana:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[0].cards[0]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card1_p0.image = card1
                self.card1_p0.configure(image=card1)

                if game.list_of_players[1].name == nickname or wygrana:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[1].cards[0]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card1_p1.image = card1
                self.card1_p1.configure(image=card1)

                if game.list_of_players[2].name == nickname or wygrana:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[2].cards[0]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card1_p2.image = card1
                self.card1_p2.configure(image=card1)

                if game.list_of_players[3].name == nickname or wygrana:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[3].cards[0]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card1 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card1_p3.image = card1
                self.card1_p3.configure(image=card1)

            except IndexError:
                pass
            try:
                if game.list_of_players[0].name == nickname or wygrana:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[0].cards[1]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card2_p0.image = card2
                self.card2_p0.configure(image=card2)

                if game.list_of_players[1].name == nickname or wygrana:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[1].cards[1]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card2_p1.image = card2
                self.card2_p1.configure(image=card2)

                if game.list_of_players[2].name == nickname or wygrana:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[2].cards[1]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card2_p2.image = card2
                self.card2_p2.configure(image=card2)

                if game.list_of_players[3].name == nickname or wygrana:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty\\" + str(game.list_of_players[3].cards[1]) + ".png")).resize(
                            (82, 115),
                            Image.ANTIALIAS))
                else:
                    card2 = ImageTk.PhotoImage(
                        Image.open(resource_path("Karty/default0.png")).resize((82, 115), Image.ANTIALIAS))
                self.card2_p3.image = card2
                self.card2_p3.configure(image=card2)

            except IndexError:
                pass
            try:
                self.stake_label_p0["text"] = "Zakład: " + str(game.list_of_players[0].stake)
                self.stake_label_p1["text"] = "Zakład: " + str(game.list_of_players[1].stake)
                self.stake_label_p2["text"] = "Zakład: " + str(game.list_of_players[2].stake)
                self.stake_label_p3["text"] = "Zakład: " + str(game.list_of_players[3].stake)
            except IndexError:
                pass
            self.pot_label["text"] = "Pula: " + str(game.pot)
            if game.game_over:
                self.actor_label["text"] = "Zwycięzca: " + str(game.winner.name)
                return
            print(f"round ended {game.round_ended}")
            self.actor_label["text"] = "Tura gracza: " + str(game.acting_player.name)
            actual_player = game.acting_player.name

            variable = StringVar(right_frame)
            variable.initialize("Akcja:")

        def action_input(self, entry0):

            response_q.put(entry0)
            game_event.set()
            time.sleep(0.1)
            if not game_info_q.empty():
                self.update(game_info_q.get())

    def score_interpreter(player):
        list_of_hand_types = ["Wysoka karta", "Jedna para", "Dwie pary", "Trójka", "Strit", "Kolor",
                              "Full",
                              "Kareta", "Poker", "Poker królewski"]
        list_of_values_to_interpret = ["Dwa", "Trzy", "Cztery", "Pięć", "Sześć", "Siedem", "Osiem", "Dziewięć",
                                       "Dziesięć",
                                       "Walet",
                                       "Dama",
                                       "Król", "As"]
        hand_type = list_of_hand_types[player.score[0]]
        mod1 = list_of_values_to_interpret[player.score[1]]
        mod2 = list_of_values_to_interpret[player.score[2]]
        mod3 = list_of_values_to_interpret[player.score[3]]

        if player.score[0] == 0:
            return hand_type + ": " + mod3
        if player.score[0] == 1:
            return hand_type + ": " + mod1
        if player.score[0] == 2:
            return hand_type + ": " + mod1 + " i " + mod2
        if player.score[0] == 3:
            return hand_type + ": " + mod1
        if player.score[0] == 4:
            return hand_type + ": " + " Wysoka karta - " + mod1
        if player.score[0] == 5:
            return hand_type + ": " + " Wysoka karta - " + mod1
        if player.score[0] == 6:
            return hand_type + ": " + mod1 + " i " + mod2
        if player.score[0] == 7:
            return hand_type + ": " + mod1
        if player.score[0] == 8:
            return hand_type + ": " + " Wysoka karta - " + mod1
        if player.score[0] == 9:
            return hand_type

    def ask_app(question, game=""):
        global twice, button0, akcja, data_retrieved, question_player, z_bazy, synchro_bit
        print("asking...")
        print(question)
        question_player = question
        answer = ""
        if game != "":
            game_info_q.put(game)
        synchro_bit = True
        z_bazy = False
        game_event.wait()
        synchro_bit = False
        if not response_q.empty():
            answer = response_q.get()
        if isinstance(answer, str) and not z_bazy and not wygrana and not answer == 'no':
            if actual_player != nickname and (
                    answer.find(
                        "Raise") >= 0 or answer == "Call" or answer == "Fold" or answer == "All in" or answer == "Check" or answer.isdigit()):
                answer = "None"
        game_event.clear()

        return answer

    def update_gui(game1):
        print("updating gui...")
        print(game1)

    def play(game):
        global host, db_rozgrywka
        game.deck.shuffle()
        global dek
        dek = [str(cards) for cards in game.deck]
        if not host:
            while True:
                try:
                    karty = [adapter_postgre_cards(str(card)) for card in
                             db_rozgrywka.query_latest_data(db_rozgrywka.query())[0].dealer_karty]
                    for i in range(len(game.deck)):
                        game.deck.pop(0)
                    for karta in karty:
                        game.deck.append(karta)
                    break
                except:
                    print("Oczekuje na karty")
                    time.sleep(1)
        game_info_q.put(game)
        update_gui(game)
        game.establish_player_attributes()
        game.deal_hole()
        game.print_round_info()
        game.act_one()
        game.print_round_info()
        if not game.round_ended:
            game.deal_flop()
            game.print_round_info()
        if not game.round_ended:
            game.ask_players()
            game.print_round_info()
        if not game.round_ended:
            game.deal_turn()
            game.print_round_info()
        if not game.round_ended:
            game.ask_players()
            game.print_round_info()
        if not game.round_ended:
            game.deal_river()
            game.print_round_info()
        if not game.round_ended:
            game.ask_players()
            game.print_round_info()
        if not game.round_ended:
            game.score_all()
            game.print_round_info()
        game.find_winners()
        game_info_q.put(game)

        game.print_round_info()
        game.round_ended = True
        print(game.winners, game.winner, [player for player in game.list_of_players_not_out if player.win])
        game.end_round()

    def run_app():
        app = App()
        app.mainloop()

    def run_game_data():
        game0 = Game()
        while True:
            play(game0)

    def synchro_game():
        test = GameSynchronisation()
        test.run()

    game_event = threading.Event()
    response_q = queue.Queue()
    game_info_q = queue.Queue()
    end_update = threading.Event()
    a = EkranLogowaniaGUI()
    a.run()
    if correct_steps[0]:
        b = EkranWyboruGUI()
        b.run()
        if correct_steps[1]:
            t1 = threading.Thread(target=run_app)
            t1.start()
            t3 = threading.Thread(target=synchro_game)
            t3.start()
            t2 = threading.Thread(target=run_game_data())
            t2.start()


class GameSynchronisation:
    def __init__(self):
        global akcja, HASLO_DO_BAZY_DANYCH, db_rozgrywka
        self.action = akcja
        self.ruch_przeciwnika = 0

    def run(self):
        global akcja, twice, question_player, actual_player, wygrana, flop, z_bazy, host, odloguj, nickname, db_rozgrywka, db_logowanie, only_once
        init_wait = False
        while True:
            time.sleep(5)
            if only_once and wygrana:
                only_once = False
                db_logowanie.patch(nickname, 'niezalogowany')
            if wygrana:
                init_wait = True
                time.sleep(10000)
            if self.action is None:
                self.action = akcja
            if init_wait:
                result = [row for row in db_rozgrywka.query_latest_data(db_rozgrywka.query())][0]
                if result.akcja_gracza == "INIT":
                    init_wait = False
            if twice == 0 and not wygrana and not init_wait:
                time.sleep(3)
                # twice = -1
                # self.action('yes')
            if question_player is not None:
                query = db_rozgrywka.query_latest_data(db_rozgrywka.query())[0]
                if query.ruch_gracza == actual_player and self.action is not None and synchro_bit and query.ruch_gracza != nickname and actual_player != nickname:
                    if odloguj:
                        # db_logowanie.patch(nickname, 'niezalogowany')
                        odloguj = False
                    if query.akcja_gracza.find('Raise') >= 0:
                        z_bazy = True
                        raise_command, raise_value = query.akcja_gracza.split()
                        akcja(raise_value)
                    else:
                        z_bazy = True
                        akcja(query.akcja_gracza)


if __name__ == "__main__":
    main()
